package com.kapture.ticket.repository;

import com.kapture.ticket.entity.Ticket;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public interface TicketRepository {

    List<Ticket> findAllTickets(long clientId,int page,int size);
    List<Ticket> findTicketById(long id);

    Ticket createTicket(Ticket ticket);
    Ticket updateTicket(Ticket ticket);


}
