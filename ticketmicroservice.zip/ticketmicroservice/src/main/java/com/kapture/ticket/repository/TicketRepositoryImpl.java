package com.kapture.ticket.repository;

import com.kapture.ticket.entity.Ticket;
import com.kapture.ticket.util.QueryUtil;
import com.kapture.ticket.configuration.DataSourceConfig;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import javax.transaction.Transactional;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class TicketRepositoryImpl implements TicketRepository {

    @Autowired
    private QueryUtil queryUtil;
    private final SessionFactory sessionFactory;
    @Autowired
    public TicketRepositoryImpl(SessionFactory sessionFactory) {

        this.sessionFactory = sessionFactory;
    }

    @Override
    public List<Ticket> findAllTickets(long clientId,int page, int size) {
        String query = "From Ticket where clientId = :CLIENT_ID";
        Map<String, Object> parametersToSet = new HashMap<>();
        parametersToSet.put("CLIENT_ID", clientId);

        return queryUtil.runQueryHelper(query, parametersToSet, Ticket.class, size, page);
    }

    @Override
    public List<Ticket> findTicketById(long id) {
        String query = "From Ticket where id = :ID";
        Map<String, Object> parametersToSet = new HashMap<>();
        parametersToSet.put("ID", id);

        return queryUtil.runQueryHelper(query, parametersToSet, Ticket.class, null, null);
    }

    public Ticket createTicket(Ticket ticket) {
        return queryUtil.executeSaveTicketQuery(ticket);
    }

    public Ticket updateTicket(Ticket ticket) {
        return queryUtil.executeUpdateQuery(ticket);
    }


}
