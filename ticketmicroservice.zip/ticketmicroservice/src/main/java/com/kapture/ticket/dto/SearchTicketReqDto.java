package com.kapture.ticket.dto;

public class SearchTicketReqDto {
}
